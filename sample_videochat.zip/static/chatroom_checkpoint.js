var audioMuted = false;
var videoMuted = false;

document.addEventListener("DOMContentLoaded", (event) => {
    var muteAudioField = document.getElementById("mute_audio_inp");
    var muteVideoField = document.getElementById("mute_video_inp");
    var muteBttn = document.getElementById("bttn_mute");
    var muteVidBttn = document.getElementById("bttn_vid_mute");
    var myVideo = document.getElementById("local_vid");

    muteBttn.addEventListener("click", (event) => {
        audioMuted = !audioMuted;
        let local_stream = myVideo.srcObject;
        local_stream.getAudioTracks().forEach((track) => { track.enabled = !audioMuted; });
        // store in hidden from input
        muteAudioField.value = (audioMuted) ? "1" : "0";
        // switch button icon
        document.getElementById("mute_icon").innerText = (audioMuted) ? "mic_off" : "mic";
    });
    muteVidBttn.addEventListener("click", (event) => {
        videoMuted = !videoMuted;
        let local_stream = myVideo.srcObject;
        local_stream.getVideoTracks().forEach((track) => { track.enabled = !videoMuted; });
        // store in hidden from input
        muteVideoField.value = (videoMuted) ? "1" : "0";
        // switch button icon
        document.getElementById("vid_mute_icon").innerText = (videoMuted) ? "videocam_off" : "videocam";
    });

    startCamera();

});


var video_allowed = false;
var audio_allowed = false;
var videoConstraints = {
    video: {
        height: 360
    }
};
var audioConstraints = {
    audio: true
};

function validate() {
    if (!video_allowed && !audio_allowed) { alert("Please allow camera and mic permissions!"); }
    else if (!video_allowed) { alert("Please allow camera permissions!"); }
    else if (!audio_allowed) { alert("Please allow mic permissions!"); }
    return true;
}

function startCamera() {
    var video_track = new MediaStream();
    navigator.mediaDevices.getUserMedia(videoConstraints)
        .then((stream) => {
            document.getElementById("local_vid").srcObject = stream;
            video_track.addTrack(stream.getVideoTracks()[0]);
            video_allowed = true;
        })
        .catch((e) => {
            console.log("Error! Unable to access camera! ", e);
        });
    navigator.mediaDevices.getUserMedia(audioConstraints)
        .then((stream) => {
            if (video_allowed) {
                stream.addTrack(video_track.getVideoTracks()[0]);
            }
            document.getElementById("local_vid").srcObject = stream;
            audio_allowed = true;
        })
        .catch((e) => {
            console.log("Error! Unable to access mic! ", e);
        })
        .then(() => {
            if (!video_allowed || !audio_allowed) {
                document.getElementById("permission_alert").style.display = "block";
            }
            if (!video_allowed && !audio_allowed) {
                document.getElementById("permission_alert").innerText = "Please allow camera and mic permissions!";
            }
            else if (!video_allowed) {
                document.getElementById("permission_alert").innerText = "Please allow camera permissions!";
            }
            else if (!audio_allowed) {
                document.getElementById("permission_alert").innerText = "Please allow mic permissions!";
            }
        });
}


